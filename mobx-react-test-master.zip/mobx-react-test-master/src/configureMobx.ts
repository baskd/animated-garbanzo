import { configure } from "mobx";

configure({ enforceActions: "always" });
